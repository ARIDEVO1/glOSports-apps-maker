---
name: "glosapp-maker"
description: "Build, package and test goodluckOS handheld apps (GA36/R36S, kennel launcher) in the V3 zip layout, reading input and files the way the desktop tester does. Use when making, porting or debugging a goodluckOS app."
---

# goodluckOS app maker

Builds apps for the goodluckOS handheld (GA36 / R36S clone, CodeZombie firmware). Apps run from the kennel launcher. Output is one zip that unpacks onto the device's home folder (`/mnt/HOME`).

## Reference
Before writing input, file-access or loading code, read the reference `glosports-desktop-test.zip` (the desktop tester). Copy its patterns rather than inventing new ones. Its `game/main.lua` shows gamepad input, folder listing, file reading and image loading. Its `.puppy` shows the launcher format.

## Ask first, only what is missing
1. App type: LÖVE (Lua), or a native binary such as kennel's C++/SDL3 build.
2. Name: lowercase letters, digits and dashes, plus a display name for the launcher.
3. First build (needs the launcher entry) or an update (no launcher entry).
4. Icon: supplied (PNG, 128x128 preferred), or make a simple one.

## Output: the V3 zip
```
<app>.zip
├── ports/<app>/                              run.sh, love, lib/, <app>.love, optional assets
├── .local/share/applications/<app>.puppy     first build only, never on an update
└── .local/share/icons/<app>.png              if the app has an icon
```
Rules:
- Paths in the zip are relative to the root, so unzipping on the device lands them under `/mnt/HOME`.
- Nothing else at `ports/` top level. Do not add a `.puppy` script there.
- On an update, leave out `.local/`. The launcher entry already exists.

### Launcher entry (match the reference)
```
[Desktop Entry]
NAME=<Display Name>
COMMAND=/mnt/HOME/ports/<app>/run.sh
ICON=/mnt/HOME/.local/share/icons/<app>.png
DEFAULT_ICON=ports
CATEGORY=Ports
COLOR=blue
```
All paths are absolute under `/mnt/HOME`. Do not use `/home/player`.

### run.sh
```sh
#!/bin/sh
here=$(dirname "$(readlink -f "$0")")
export VDP_DIR="$here"
export LD_LIBRARY_PATH="$here/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export SDL_VIDEODRIVER="${SDL_VIDEODRIVER:-kmsdrm}"
export LOVE_GRAPHICS_USE_OPENGLES=1
exec "$here/love" "$here/<app>.love" "$@" > "$here/run.log" 2>&1
```
The runtime (`love`, `lib/`) lives in the app's own `ports/<app>/` folder. Don't rely on another app's runtime.

## Input
- Gamepad: `love.gamepadpressed` and `love.gamepadreleased`. Names: `a b x y start back leftshoulder rightshoulder dpup dpdown dpleft dpright`.
- Left stick: `joy:getGamepadAxis("leftx")` and `"lefty"`, only when `joy:isGamepad()`.
- Fallback when the stick is not a mapped gamepad: `joy:getAxis(1..4)`.
- Deadzone 0.15.
- Keyboard fallback so the app can be tested on a PC.

## File access on the device
- Home folder: `io.popen("cd ~ && pwd 2>/dev/null")`, falling back to `os.getenv("HOME")` or `/mnt/HOME`. Lua does not expand `~`.
- List a folder: `io.popen(string.format('ls -1p "%s" 2>/dev/null', dir))`. Names ending in `/` are folders.
- Read a file: `io.open(path, "rb")`. Size: `f:seek("end")`.
- Images: read the bytes, then `love.graphics.newImage(love.filesystem.newFileData(bytes, name))` inside `pcall`.
- Do not use `love.filesystem.mount` for folders outside the save folder. The folders came up empty on the device.
- Save data: `love.filesystem.write` and `read`, in `~/.local/share/love/<identity>/`. `love.filesystem.read` returns two values. Wrap it in parentheses before `tonumber`.
- Assets shipped in the port (themes, images): find them with `VDP_DIR` from run.sh, falling back to `love.filesystem.getSource()` with the `.love` file name stripped.

## Steps
1. Create `apps/<app>/main.lua` and `conf.lua`. `conf.lua` sets `identity`, a 640x480 window, and turns off physics, video and touch.
2. Syntax check every Lua file before building.
3. Build `<app>.love`: a zip with `main.lua` (and `conf.lua`) at its root.
4. Assemble `ports/<app>/` (run.sh, love, lib/, the .love, assets). Add the `.local/` entries on a first build.
5. Zip the root as `<app>.zip`.
6. On the device, run `ports/<app>/run.sh` from a terminal, then read `run.log`. Launch from kennel only after that works.

## Pitfalls
- Design at a fixed 640x480 and scale to the panel. Don't resize the window under kmsdrm.
- Don't `load()` user text. Use a small parser, and wrap evaluation in `pcall`.
- Check the launcher paths against `/mnt/HOME` first when a launch fails.
- Keep `lib/licenses/` in the port for LÖVE (zlib) and other bundled libraries.

## Output message
Name the zip, list the files in it, and give the next device step (unzip, then run `run.sh` from a terminal).