-- Desktop & Hardware Diagnostic App for goodluckOS (640x480)
local cursor = { x = 320, y = 240, speed = 260 }
local deadzone = 0.15

local joy = nil
local inputState = {
    dpad = { up = false, down = false, left = false, right = false },
    axes = { lx = 0, ly = 0, rx = 0, ry = 0 },
    buttons = { a = false, b = false, x = false, y = false, l1 = false, r1 = false, start = false, back = false },
    lastEvent = "None"
}

local homeDir = "/"
local currentPath = "/"
local files = {}
local selectedIndex = 1
local scrollOffset = 0
local maxVisibleRows = 12
local previewWindow = nil
local contextMenu = nil

local function getHomeDir()
    local p = io.popen("cd ~ && pwd 2>/dev/null")
    if p then
        local res = p:read("*l")
        p:close()
        if res and res ~= "" then
            return res
        end
    end
    return os.getenv("HOME") or "/mnt/HOME"
end

-- Check if currentPath is at the main storage boundary
local function isAtStorageRoot(path)
    return path == "/" or path == "/mnt" or path == homeDir
end

-- Check image extension
local function isImageFile(filename)
    local ext = filename:match("%.([^%.]+)$")
    if not ext then return false end
    ext = ext:lower()
    return ext == "png" or ext == "jpg" or ext == "jpeg" or ext == "bmp" or ext == "tga"
end

-- Release previous preview GPU resources safely
local function closePreview()
    if previewWindow and previewWindow.image then
        previewWindow.image:release()
    end
    previewWindow = nil
end

local function scanDir(targetPath)
    local nextPath = targetPath or homeDir
    if nextPath == "" then nextPath = "/" end

    -- Failsafe: prevent traversing above the main storage boundary or into unreadable system dirs
    if currentPath == homeDir and nextPath ~= homeDir and #nextPath < #homeDir then
        inputState.lastEvent = "Failsafe: At Main Storage Root"
        return
    end
    if nextPath == "/" or nextPath == "/mnt" then
        if currentPath ~= "/" and currentPath ~= "/mnt" then
            inputState.lastEvent = "Failsafe: Blocked Parent Above Storage"
            return
        end
    end

    local newFiles = {}

    -- Only show '..' if we are inside a subfolder below homeDir
    if not isAtStorageRoot(nextPath) then
        local parent = nextPath:match("^(.*)/[^/]+$")
        if not parent or parent == "" then parent = homeDir end
        table.insert(newFiles, {
            name = "..",
            isDir = true,
            fullPath = parent,
            isParent = true
        })
    end

    local cmd = string.format('ls -1p "%s" 2>/dev/null', nextPath)
    local p = io.popen(cmd)
    if p then
        for entry in p:lines() do
            local isDir = entry:sub(-1) == "/"
            local cleanName = isDir and entry:sub(1, -2) or entry
            local full = (nextPath == "/" and "" or nextPath) .. "/" .. cleanName
            table.insert(newFiles, {
                name = cleanName,
                isDir = isDir,
                isImage = (not isDir) and isImageFile(cleanName),
                fullPath = full
            })
        end
        p:close()
    end

    if #newFiles == 0 then
        table.insert(newFiles, {
            name = "(Empty folder: " .. nextPath .. ")",
            isDir = false,
            isPlaceholder = true
        })
    end

    currentPath = nextPath
    files = newFiles
    selectedIndex = 1
    scrollOffset = 0
end

local function updateScroll()
    if selectedIndex <= scrollOffset then
        scrollOffset = selectedIndex - 1
    elseif selectedIndex > scrollOffset + maxVisibleRows then
        scrollOffset = selectedIndex - maxVisibleRows
    end
end

local function inspectFile(item)
    if not item or item.isPlaceholder then return end
    if item.isDir then
        scanDir(item.fullPath)
        inputState.lastEvent = "Opened Dir: " .. item.name
        return
    end

    local f = io.open(item.fullPath, "rb")
    if not f then
        closePreview()
        previewWindow = {
            title = "Read-Only / Access Error",
            body = "Could not open:\n" .. item.fullPath
        }
        return
    end

    local size = f:seek("end")
    f:seek("set", 0)

    -- Load actual image into LÖVE via FileData if file has an image extension
    if item.isImage then
        local rawBytes = f:read("*a")
        f:close()
        closePreview()

        local ok, imgOrErr = pcall(function()
            local fileData = love.filesystem.newFileData(rawBytes, item.name)
            return love.graphics.newImage(fileData)
        end)

        if ok and imgOrErr then
            imgOrErr:setFilter("nearest", "nearest")
            local iw, ih = imgOrErr:getDimensions()
            previewWindow = {
                title = string.format("%s (%dx%d px, %d B)", item.name, iw, ih, size),
                image = imgOrErr,
                imgW = iw,
                imgH = ih
            }
            inputState.lastEvent = "Loaded Image: " .. item.name
        else
            previewWindow = {
                title = "Image Decode Error: " .. item.name,
                body = "Failed to decode image:\n" .. tostring(imgOrErr)
            }
        end
        return
    end

    -- Text/Binary snippet fallback for non-image files
    local snippet = f:read(280) or ""
    f:close()
    closePreview()

    snippet = snippet:gsub("[^%w%s%p]", ".")
    previewWindow = {
        title = item.name .. " (" .. tostring(size) .. " bytes)",
        body = snippet ~= "" and snippet or "[Empty File]"
    }
    inputState.lastEvent = "Previewed: " .. item.name
end

function love.load()
    love.graphics.setDefaultFilter("nearest", "nearest")
    font = love.graphics.newFont(13)
    fontSmall = love.graphics.newFont(11)
    love.graphics.setFont(font)

    homeDir = getHomeDir()

    local joysticks = love.joystick.getJoysticks()
    if #joysticks > 0 then
        joy = joysticks[1]
        inputState.lastEvent = "Connected: " .. joy:getName()
    else
        inputState.lastEvent = "No Gamepad Detected (Keyboard Fallback Active)"
    end

    scanDir(homeDir)
end

function love.joystickadded(j)
    joy = j
    inputState.lastEvent = "Gamepad Added: " .. j:getName()
end

local function triggerLeftClick()
    inputState.lastEvent = string.format("Left Click @ (%d, %d)", math.floor(cursor.x), math.floor(cursor.y))

    if contextMenu then
        if cursor.x >= contextMenu.x and cursor.x <= contextMenu.x + 130 and
           cursor.y >= contextMenu.y and cursor.y <= contextMenu.y + 78 then
            if cursor.y < contextMenu.y + 26 then
                scanDir(homeDir)
                inputState.lastEvent = "Context: Jump to ~"
            elseif cursor.y < contextMenu.y + 52 then
                scanDir(currentPath)
                inputState.lastEvent = "Context: Refreshed"
            else
                closePreview()
                inputState.lastEvent = "Context: Closed Window"
            end
        end
        contextMenu = nil
        return
    end

    if previewWindow then
        if cursor.x >= 565 and cursor.x <= 595 and cursor.y >= 75 and cursor.y <= 100 then
            closePreview()
            return
        end
    end

    if cursor.x >= 20 and cursor.x <= 360 and cursor.y >= 75 and cursor.y <= 363 then
        local row = math.floor((cursor.y - 75) / 24) + 1 + scrollOffset
        if files[row] then
            selectedIndex = row
            inspectFile(files[row])
        end
    end

    if cursor.x >= 270 and cursor.x <= 355 and cursor.y >= 42 and cursor.y <= 66 then
        scanDir(homeDir)
        inputState.lastEvent = "Reset to ~"
    end
end

local function triggerRightClick()
    inputState.lastEvent = string.format("Right Click @ (%d, %d)", math.floor(cursor.x), math.floor(cursor.y))
    contextMenu = {
        x = math.min(cursor.x, 500),
        y = math.min(cursor.y, 360)
    }
end

function love.gamepadpressed(joystick, button)
    inputState.lastEvent = "Btn Down: " .. tostring(button)
    if button == "dpup" then
        inputState.dpad.up = true
        selectedIndex = math.max(1, selectedIndex - 1)
        updateScroll()
    elseif button == "dpdown" then
        inputState.dpad.down = true
        selectedIndex = math.min(#files, selectedIndex + 1)
        updateScroll()
    elseif button == "dpleft" then
        inputState.dpad.left = true
    elseif button == "dpright" then
        inputState.dpad.right = true
    elseif button == "a" then
        inputState.buttons.a = true
        triggerLeftClick()
    elseif button == "b" then
        inputState.buttons.b = true
        if previewWindow then
            closePreview()
            inputState.lastEvent = "Closed Preview [B]"
        else
            triggerRightClick()
        end
    elseif button == "x" then
        inputState.buttons.x = true
        inspectFile(files[selectedIndex])
    elseif button == "y" then
        inputState.buttons.y = true
        scanDir(homeDir)
    elseif button == "start" then
        inputState.buttons.start = true
    elseif button == "back" then
        inputState.buttons.back = true
    end

    if inputState.buttons.start and inputState.buttons.back then
        love.event.quit()
    end
end

function love.gamepadreleased(joystick, button)
    if button == "dpup" then inputState.dpad.up = false
    elseif button == "dpdown" then inputState.dpad.down = false
    elseif button == "dpleft" then inputState.dpad.left = false
    elseif button == "dpright" then inputState.dpad.right = false
    elseif button == "a" then inputState.buttons.a = false
    elseif button == "b" then inputState.buttons.b = false
    elseif button == "x" then inputState.buttons.x = false
    elseif button == "y" then inputState.buttons.y = false
    elseif button == "start" then inputState.buttons.start = false
    elseif button == "back" then inputState.buttons.back = false
    end
end

function love.keypressed(key)
    if key == "escape" then love.event.quit()
    elseif key == "up" then
        selectedIndex = math.max(1, selectedIndex - 1)
        updateScroll()
    elseif key == "down" then
        selectedIndex = math.min(#files, selectedIndex + 1)
        updateScroll()
    elseif key == "return" or key == "z" then triggerLeftClick()
    elseif key == "x" then
        if previewWindow then closePreview() else triggerRightClick() end
    elseif key == "r" then scanDir(homeDir)
    end
end

function love.update(dt)
    local lx, ly, rx, ry = 0, 0, 0, 0

    if joy and joy:isGamepad() then
        lx = joy:getGamepadAxis("leftx")
        ly = joy:getGamepadAxis("lefty")
        rx = joy:getGamepadAxis("rightx")
        ry = joy:getGamepadAxis("righty")
    elseif joy then
        lx = joy:getAxis(1) or 0
        ly = joy:getAxis(2) or 0
        rx = joy:getAxis(3) or 0
        ry = joy:getAxis(4) or 0
    end

    inputState.axes.lx, inputState.axes.ly = lx, ly
    inputState.axes.rx, inputState.axes.ry = rx, ry

    local mag = math.sqrt(lx * lx + ly * ly)
    if mag > deadzone then
        local norm = (mag - deadzone) / (1 - deadzone)
        cursor.x = cursor.x + (lx / mag) * norm * cursor.speed * dt
        cursor.y = cursor.y + (ly / mag) * norm * cursor.speed * dt
    end

    cursor.x = math.max(0, math.min(639, cursor.x))
    cursor.y = math.max(0, math.min(479, cursor.y))
end

local function drawDpadWidget(cx, cy)
    love.graphics.setColor(0.2, 0.23, 0.28)
    love.graphics.rectangle("fill", cx - 12, cy - 34, 24, 68, 3)
    love.graphics.rectangle("fill", cx - 34, cy - 12, 68, 24, 3)

    love.graphics.setColor(0.25, 0.78, 0.45)
    if inputState.dpad.up then love.graphics.rectangle("fill", cx - 10, cy - 32, 20, 20, 2) end
    if inputState.dpad.down then love.graphics.rectangle("fill", cx - 10, cy + 12, 20, 20, 2) end
    if inputState.dpad.left then love.graphics.rectangle("fill", cx - 32, cy - 10, 20, 20, 2) end
    if inputState.dpad.right then love.graphics.rectangle("fill", cx + 12, cy - 10, 20, 20, 2) end
end

local function drawStickWidget(cx, cy, ax, ay, label)
    love.graphics.setColor(0.2, 0.23, 0.28)
    love.graphics.circle("line", cx, cy, 28)
    love.graphics.setColor(0.4, 0.45, 0.55)
    love.graphics.circle("fill", cx + ax * 22, cy + ay * 22, 7)
    love.graphics.setFont(fontSmall)
    love.graphics.setColor(0.85, 0.9, 0.95)
    love.graphics.printf(label, cx - 35, cy + 32, 70, "center")
    love.graphics.setFont(font)
end

function love.draw()
    love.graphics.clear(0.11, 0.14, 0.19)

    love.graphics.setColor(0.16, 0.20, 0.27)
    love.graphics.rectangle("fill", 0, 0, 640, 28)
    love.graphics.setColor(0.9, 0.95, 1)
    love.graphics.print("goodluckOS Desktop Tester  |  A: Click/Open  B: Close/Menu  START+SELECT: Exit", 10, 6)

    love.graphics.setColor(0.15, 0.18, 0.24)
    love.graphics.rectangle("fill", 15, 38, 350, 345, 6)
    love.graphics.setColor(0.22, 0.27, 0.36)
    love.graphics.rectangle("fill", 15, 38, 350, 30, 6)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("ls: " .. currentPath, 24, 45)

    love.graphics.setColor(0.24, 0.48, 0.78)
    love.graphics.rectangle("fill", 270, 42, 85, 22, 4)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Home (~) [Y]", 270, 45, 85, "center")

    for row = 1, maxVisibleRows do
        local idx = row + scrollOffset
        local item = files[idx]
        if not item then break end

        local rowY = 75 + (row - 1) * 24
        if idx == selectedIndex then
            love.graphics.setColor(0.25, 0.42, 0.68)
            love.graphics.rectangle("fill", 20, rowY, 340, 22, 3)
        end

        local prefix = "      "
        if item.isDir then
            love.graphics.setColor(0.95, 0.80, 0.35)
            prefix = "[DIR] "
        elseif item.isImage then
            love.graphics.setColor(0.45, 0.90, 0.65)
            prefix = "[IMG] "
        else
            love.graphics.setColor(0.90, 0.92, 0.96)
        end
        love.graphics.print(prefix .. item.name, 26, rowY + 3)
    end

    love.graphics.setColor(0.15, 0.18, 0.24)
    love.graphics.rectangle("fill", 380, 38, 245, 345, 6)
    love.graphics.setColor(0.22, 0.27, 0.36)
    love.graphics.rectangle("fill", 380, 38, 245, 30, 6)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Hardware & Input Telemetry", 390, 45)

    drawDpadWidget(435, 120)
    drawStickWidget(520, 115, inputState.axes.lx, inputState.axes.ly, "L-Stick (Mouse)")
    drawStickWidget(585, 115, inputState.axes.rx, inputState.axes.ry, "R-Stick")

    love.graphics.setFont(fontSmall)
    love.graphics.setColor(0.8, 0.85, 0.9)
    love.graphics.print(string.format("LX: %.2f   LY: %.2f", inputState.axes.lx, inputState.axes.ly), 392, 175)
    love.graphics.print(string.format("RX: %.2f   RY: %.2f", inputState.axes.rx, inputState.axes.ry), 392, 192)
    love.graphics.print(string.format("Cursor: %d, %d", math.floor(cursor.x), math.floor(cursor.y)), 392, 212)
    love.graphics.printf("Last Event:\n" .. inputState.lastEvent, 392, 238, 220, "left")

    local btns = {
        { "A (L-Click)", inputState.buttons.a },
        { "B (Back/Menu)", inputState.buttons.b },
        { "X (Open)", inputState.buttons.x },
        { "Y (Home ~)", inputState.buttons.y }
    }
    for idx, b in ipairs(btns) do
        local bx = 392 + ((idx - 1) % 2) * 112
        local by = 295 + math.floor((idx - 1) / 2) * 32
        love.graphics.setColor(b[2] and {0.25, 0.78, 0.45} or {0.22, 0.25, 0.32})
        love.graphics.rectangle("fill", bx, by, 104, 24, 4)
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf(b[1], bx, by + 5, 104, "center")
    end
    love.graphics.setFont(font)

    love.graphics.setColor(0.16, 0.20, 0.27)
    love.graphics.rectangle("fill", 0, 452, 640, 28)
    love.graphics.setColor(0.75, 0.82, 0.9)
    love.graphics.print("D-Pad: Scroll List  |  Left Stick: Move Pointer  |  A/X: Open Image/File", 10, 458)

    if previewWindow then
        love.graphics.setColor(0.12, 0.15, 0.20, 0.98)
        love.graphics.rectangle("fill", 100, 70, 500, 310, 6)
        love.graphics.setColor(0.35, 0.55, 0.85)
        love.graphics.rectangle("line", 100, 70, 500, 310, 6)
        love.graphics.rectangle("fill", 100, 70, 500, 30, 6)

        love.graphics.setColor(1, 1, 1)
        love.graphics.print(previewWindow.title, 110, 77)

        love.graphics.setColor(0.82, 0.25, 0.25)
        love.graphics.rectangle("fill", 565, 75, 30, 20, 3)
        love.graphics.setColor(1, 1, 1)
        love.graphics.printf("X", 565, 77, 30, "center")

        if previewWindow.image then
            -- Draw checkerboard backdrop behind image to verify alpha transparency
            local boxX, boxY, boxW, boxH = 115, 110, 470, 255
            love.graphics.setColor(0.18, 0.21, 0.26)
            love.graphics.rectangle("fill", boxX, boxY, boxW, boxH)

            -- Scale image proportionally to fit inside preview box
            local scale = math.min(boxW / previewWindow.imgW, boxH / previewWindow.imgH)
            if scale > 4 then scale = 4 end
            local drawW = previewWindow.imgW * scale
            local drawH = previewWindow.imgH * scale
            local drawX = boxX + (boxW - drawW) / 2
            local drawY = boxY + (boxH - drawH) / 2

            love.graphics.setColor(1, 1, 1, 1)
            love.graphics.draw(previewWindow.image, drawX, drawY, 0, scale, scale)
        else
            love.graphics.setFont(fontSmall)
            love.graphics.printf(previewWindow.body, 115, 112, 470, "left")
            love.graphics.setFont(font)
        end
    end

    if contextMenu then
        love.graphics.setColor(0.22, 0.26, 0.34)
        love.graphics.rectangle("fill", contextMenu.x, contextMenu.y, 130, 78, 4)
        love.graphics.setColor(0.5, 0.6, 0.75)
        love.graphics.rectangle("line", contextMenu.x, contextMenu.y, 130, 78, 4)
        love.graphics.setColor(1, 1, 1)
        love.graphics.print("Jump to ~", contextMenu.x + 10, contextMenu.y + 6)
        love.graphics.print("Refresh Dir", contextMenu.x + 10, contextMenu.y + 30)
        love.graphics.print("Close Preview", contextMenu.x + 10, contextMenu.y + 54)
    end

    love.graphics.setColor(1, 1, 1)
    love.graphics.polygon("fill", cursor.x, cursor.y, cursor.x, cursor.y + 16, cursor.x + 11, cursor.y + 11)
    love.graphics.setColor(0, 0, 0)
    love.graphics.polygon("line", cursor.x, cursor.y, cursor.x, cursor.y + 16, cursor.x + 11, cursor.y + 11)
end
