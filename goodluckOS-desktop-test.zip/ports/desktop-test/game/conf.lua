function love.conf(t)
    t.identity = "desktop_test"
    t.console = false

    t.window.title = "goodluckOS Desktop & Input Tester"
    t.window.width = 640
    t.window.height = 480
    t.window.fullscreen = true
    t.window.vsync = 1

    t.modules.audio = false
    t.modules.sound = false
    t.modules.physics = false
    t.modules.video = false
end
