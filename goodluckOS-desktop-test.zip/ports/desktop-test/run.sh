#!/bin/sh
set -eu

DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$DIR"

OPENSEEK_DIR="$(dirname "$DIR")/openseek"
export LD_LIBRARY_PATH="$DIR/lib:$OPENSEEK_DIR/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export SDL_GAMECONTROLLERCONFIG="${SDL_GAMECONTROLLERCONFIG:-}"

if [ -x "$DIR/love" ]; then
    LOVE_BIN="$DIR/love"
elif [ -x "$OPENSEEK_DIR/love" ]; then
    LOVE_BIN="$OPENSEEK_DIR/love"
elif command -v love >/dev/null 2>&1; then
    LOVE_BIN="$(command -v love)"
else
    echo "ERROR: love binary not found in $DIR, $OPENSEEK_DIR, or PATH" >&2
    exit 1
fi

if [ -f "$DIR/desktop-test.love" ]; then
    exec "$LOVE_BIN" "$DIR/desktop-test.love"
else
    exec "$LOVE_BIN" "$DIR/game"
fi
