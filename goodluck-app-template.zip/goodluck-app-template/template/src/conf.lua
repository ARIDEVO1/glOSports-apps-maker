-- Window and module settings. The identity sets the save folder name.
function love.conf(t)
    t.identity = "{{NAME}}"
    t.window.title = "{{TITLE}}"
    t.window.width = 640
    t.window.height = 480
    t.window.resizable = false
    t.window.usedpiscale = false
    t.modules.physics = false
    t.modules.video = false
    t.modules.touch = false
end
