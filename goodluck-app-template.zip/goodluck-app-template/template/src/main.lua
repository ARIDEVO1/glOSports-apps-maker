-- {{TITLE}}: starter app for goodluckOS. Edit freely.
-- Controls: d-pad or left stick moves the square. A (or Space) changes its colour and
-- counts a click, which is saved. Start (or Escape) quits.

local VW, VH = 640, 480                 -- design size; the drawing is scaled to fit the screen
local SAVE_FILE = "save.txt"            -- lives in ~/.local/share/love/{{NAME}}/

local player = { x = VW / 2, y = VH / 2, size = 32, speed = 240, colour = 1 }
local colours = { { 0.40, 0.90, 0.50 }, { 0.90, 0.50, 0.40 }, { 0.50, 0.60, 1.00 } }
local clicks = 0
local font

function love.load()
    font = love.graphics.newFont(18)
    -- read() returns two values (contents, size), so wrap it in parentheses.
    clicks = tonumber((love.filesystem.read(SAVE_FILE))) or 0
end

-- Reads the d-pad, the left stick and the keyboard. Returns dx, dy in -1..1.
local function read_direction()
    local dx, dy = 0, 0
    if love.keyboard.isDown("left", "a") then dx = dx - 1 end
    if love.keyboard.isDown("right", "d") then dx = dx + 1 end
    if love.keyboard.isDown("up", "w") then dy = dy - 1 end
    if love.keyboard.isDown("down", "s") then dy = dy + 1 end

    local joy = love.joystick.getJoysticks()[1]
    if joy and joy:isGamepad() then
        if joy:isGamepadDown("dpleft") then dx = dx - 1 end
        if joy:isGamepadDown("dpright") then dx = dx + 1 end
        if joy:isGamepadDown("dpup") then dy = dy - 1 end
        if joy:isGamepadDown("dpdown") then dy = dy + 1 end
        local lx, ly = joy:getGamepadAxis("leftx"), joy:getGamepadAxis("lefty")
        if math.abs(lx) > 0.25 then dx = dx + lx end
        if math.abs(ly) > 0.25 then dy = dy + ly end
    end
    return math.max(-1, math.min(1, dx)), math.max(-1, math.min(1, dy))
end

function love.update(dt)
    local dx, dy = read_direction()
    local half = player.size / 2
    player.x = math.max(half, math.min(VW - half, player.x + dx * player.speed * dt))
    player.y = math.max(half, math.min(VH - half, player.y + dy * player.speed * dt))
end

function love.draw()
    local w, h = love.graphics.getDimensions()
    local s = math.min(w / VW, h / VH)
    love.graphics.clear(0.06, 0.07, 0.10)

    love.graphics.push()
    love.graphics.translate((w - VW * s) / 2, (h - VH * s) / 2)
    love.graphics.scale(s, s)
    love.graphics.setFont(font)

    love.graphics.setColor(colours[player.colour])
    love.graphics.rectangle("fill", player.x - player.size / 2, player.y - player.size / 2,
        player.size, player.size, 6, 6)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print("{{TITLE}}   clicks: " .. clicks, 12, 10)
    love.graphics.printf("D-pad moves   A: colour + click   Start: quit", 0, VH - 30, VW, "center")
    love.graphics.pop()
end

local function press_a()
    player.colour = player.colour % #colours + 1
    clicks = clicks + 1
    love.filesystem.write(SAVE_FILE, tostring(clicks))
end

function love.gamepadpressed(_, button)
    if button == "a" then
        press_a()
    elseif button == "start" then
        love.event.quit()
    end
end

function love.keypressed(key)
    if key == "space" or key == "return" then
        press_a()
    elseif key == "escape" then
        love.event.quit()
    end
end
