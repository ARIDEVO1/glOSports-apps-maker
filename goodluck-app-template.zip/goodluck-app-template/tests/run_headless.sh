#!/bin/sh
# Builds the app, wraps it in a test harness, and runs 60 frames on a virtual screen.
# Pass: the log contains "RESULT: PASS". Any error in load, update or draw prints
# "RESULT: FAIL" with a traceback.
# Needs a desktop LÖVE 11.x (set LOVE=/path/to/love) and xvfb-run on Linux.
# The bundled runtime/love is for the handheld and does not run on a PC.
# usage: tests/run_headless.sh <name>
set -e
cd "$(dirname "$0")/.."
NAME="$1"
LOVE="${LOVE:-love}"
python3 build.py > /dev/null
python3 tests/make_test_love.py "$NAME" > /dev/null
set +e
OUT=$(SDL_AUDIODRIVER=dummy timeout 60 xvfb-run -a -s "-screen 0 1280x720x24" "$LOVE" "ports/$NAME/$NAME-test.love" 2>&1)
set -e
if echo "$OUT" | grep -q "RESULT: PASS"; then
    echo "PASS: $NAME loads, updates and draws without errors"
else
    echo "FAIL: $NAME"; echo "$OUT" | grep -v -E "ALSA|ALSOFT|pw\.conf|XIO|Could not open|after .* requests"
    exit 1
fi
