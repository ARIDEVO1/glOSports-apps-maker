# Making your own app for goodluckOS

This tutorial takes you from an empty folder to an app running on the handheld. Each step has a time estimate. The first full run takes about 40 minutes.

You need:
- A computer with Python 3 and Pillow (`pip install pillow`).
- LÖVE 11.x for testing on the computer (Linux: `sudo apt install love`). You also need `xvfb-run` to run the tests without a screen (`sudo apt install xvfb`).
- The handheld with kennel, and SSH or a terminal on it if you have one.

---

## 1. How an app is packaged (5 min, reading only)

Every app is a folder under `ports/` with four parts:

```
ports/<name>/
  <name>.love   your game: a zip with main.lua at its root
  love          the LÖVE runtime (ARM build for the handheld)
  lib/          the libraries the runtime needs
  run.sh        starts the runtime with your game
```

The launcher reads a file in `.local/share/applications/<name>.puppy`. It tells kennel the app's name, icon and the command to run (`run.sh`). Every path on the handheld starts with `/home/player/`.

Everything else is for you to write: your game code, and whatever images or data it needs.

## 2. Create the app (2 min)

From the template folder:

```sh
python3 new_app.py my-app "My App"
```

This creates:
- `apps/my-app/main.lua` and `conf.lua`: your code.
- `ports/my-app/`: `run.sh`, `love` and `lib/`, ready to copy to the device.
- `.local/share/applications/my-app.puppy`: the launcher entry.
- `.local/share/icons/my-app.png`: the icon, made from the first letter of the name.

Names must be lowercase, with letters, digits and dashes. The name becomes the folder name on the device.

## 3. Build and test on the computer (5 min)

```sh
python3 build.py
tests/run_headless.sh my-app
```

`build.py` zips your code into `ports/my-app/my-app.love`. The test runs the game for 60 frames and prints `PASS` or `FAIL` with the traceback. It catches errors in load, update and draw. If it prints `FAIL`, read the traceback: the first line names the file and line number.

To play it on your desktop with a window:

```sh
love ports/my-app/my-app.love
```

Use the keyboard (arrows or WASD, Space, Escape) or a gamepad if you have one.

## 4. Put it on the handheld (10 min)

Copy these to the device, keeping the same folders:
- `ports/my-app/` → `/home/player/ports/my-app/`
- `.local/share/applications/my-app.puppy` → `/home/player/.local/share/applications/`
- `.local/share/icons/my-app.png` → `/home/player/.local/share/icons/`

Then:
1. Start it from a terminal first: `/home/player/ports/my-app/run.sh`.
2. If it fails, read `/home/player/ports/my-app/run.log`.
3. When it works from the terminal, open kennel. The app should show up under Ports with its icon.

Do not skip step 1. It's much easier to read an error in a terminal than in the launcher.

## 5. Know the controls (10 min)

Your code receives gamepad events with LÖVE's standard names:

| Button | Name in code | Button | Name in code |
|---|---|---|---|
| A | `a` | Start | `start` |
| B | `b` | Select / Back | `back` |
| X | `x` | Left shoulder | `leftshoulder` |
| Y | `y` | Right shoulder | `rightshoulder` |

The d-pad is `dpup`, `dpdown`, `dpleft`, `dpright`. The left stick is read with `joy:getGamepadAxis("leftx")` and `"lefty"`, as in the template.

The R36S / goodluckOS controller may not match these names exactly. To check, add this to your code temporarily:

```lua
function love.gamepadpressed(joy, button)
    print("button: " .. button)
end
```

Run the app from the terminal on the device, press each button, and read the names in `run.log`. Then use those names in your code.

## 6. Build your app (as long as you like)

Start from `apps/my-app/main.lua`. It already has:
- A fixed 640×480 design size, scaled to fit the screen (`love.draw` uses `push`, `scale`, `pop`).
- The d-pad, the left stick and the keyboard for movement.
- A save file: `love.filesystem.write` and `love.filesystem.read`.

Each time you change something:
1. Save `main.lua`.
2. `python3 build.py`, then `tests/run_headless.sh my-app`.
3. Copy `ports/my-app/my-app.love` to the device. Then run it.

Only the `.love` file changes. `run.sh`, `love` and `lib/` stay the same.

### Typing text with the on-screen keyboard

The handheld has no keyboard, so use `shared/osk.lua`. The notebook and calculator apps use it. Copy the pattern from `apps/notes`, or:

```lua
local Osk = require "osk"
local K = Osk.key
local keys = Osk.new({
    { K"1", K"2", K"3" },
    { K"a", K"b", K("DEL", "@del", 2) },
})
-- In love.gamepadpressed: "dpleft"/"dpright" call keys:move(0, -1)/(0, 1),
-- "a" presses keys:current().value.
```

The `build.py` script includes `shared/` in every app's zip, so `require "osk"` works in your code.

### Where your files go

- `love.filesystem.write("file.txt", text)` saves to `/home/player/.local/share/love/<identity>/`. The identity is set in `conf.lua`. Use this for anything you want to keep.
- Don't write to the app's own folder. The `.love` file is replaced whenever you copy a new version.

## 7. Troubleshooting

| Symptom | Likely cause | What to do |
|---|---|---|
| The app doesn't appear in kennel | The `.puppy` file path or name is wrong | Check the file is in `.local/share/applications/` and that `COMMAND` points to `run.sh` |
| Black screen, then it closes | Something failed at start | Read `run.log` in the app's folder |
| `Error: ... attempt to index nil` | A variable was nil when used | Traceback line numbers point to the place to check |
| Screen is the wrong size or cut off | The panel size is not 640×480 | Change the drawing scale in `love.draw`, or the design size `VW`, `VH` |
| Buttons do nothing | The button names are different | Use step 5 to find the real names |

## 8. Share it, and licence it (optional)

- Your own code can be any licence you choose. `shared/osk.lua` and the template are MIT.
- LÖVE is zlib-licensed. Its licence is in `runtime/lib/licenses/` and must be kept if you share the runtime.
- If you share an app with someone else, include the `lib/licenses` folder with it.

---

## Quick reference

```sh
python3 new_app.py my-app "My App"   # create an app
python3 build.py                     # build all apps into .love files
tests/run_headless.sh my-app         # check an app loads and runs
love ports/my-app/my-app.love        # run it on the computer
```
