#!/usr/bin/env python3
"""Create a new goodluckOS app from the template.

usage: python3 new_app.py <name> ["Display Name"]

  <name>        lowercase letters, digits and dashes, starting with a letter.
                Used for the folders, the .love file and the .puppy file.
  Display Name  shown in the launcher. Defaults to the name in title case.

Creates:
  apps/<name>/              main.lua and conf.lua (edit these)
  ports/<name>/             run.sh, the LÖVE runtime and lib/
  .local/share/applications/<name>.puppy
  .local/share/icons/<name>.png
"""
import pathlib
import re
import shutil
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = pathlib.Path(__file__).resolve().parent


def make_icon(name, title, out):
    img = Image.new("RGBA", (64, 64), (15, 18, 26, 255))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((6, 6, 58, 58), radius=8, fill=(89, 217, 140, 255))
    letter = (title[:1] or "?").upper()
    font = ImageFont.load_default(size=36)
    left, top, right, bottom = d.textbbox((0, 0), letter, font=font)
    d.text((32 - (right + left) / 2, 32 - (bottom + top) / 2), letter, fill=(15, 18, 26, 255), font=font)
    img.save(out)


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    name = sys.argv[1]
    title = sys.argv[2] if len(sys.argv) > 2 else name.replace("-", " ").title()
    if not re.fullmatch(r"[a-z][a-z0-9-]*", name):
        sys.exit("name must be lowercase letters, digits and dashes, starting with a letter")

    app = ROOT / "apps" / name
    if app.exists() or (ROOT / "ports" / name).exists():
        sys.exit(f"'{name}' already exists in apps/ or ports/")

    # 1. Source files from the template, with the name and title filled in.
    app.mkdir(parents=True)
    for src in sorted((ROOT / "template" / "src").glob("*.lua")):
        text = src.read_text(encoding="utf-8")
        text = text.replace("{{NAME}}", name).replace("{{TITLE}}", title)
        (app / src.name).write_text(text, encoding="utf-8")

    # 2. The port folder: runtime, lib and launcher script.
    port = ROOT / "ports" / name
    port.mkdir(parents=True)
    shutil.copy2(ROOT / "runtime" / "love", port / "love")
    shutil.copytree(ROOT / "runtime" / "lib", port / "lib")
    run = (ROOT / "template" / "run.sh").read_text(encoding="utf-8").replace("{{NAME}}", name)
    (port / "run.sh").write_text(run, encoding="utf-8")
    (port / "run.sh").chmod(0o755)

    # 3. Launcher entry and icon.
    apps_dir = ROOT / ".local" / "share" / "applications"
    icons_dir = ROOT / ".local" / "share" / "icons"
    apps_dir.mkdir(parents=True, exist_ok=True)
    icons_dir.mkdir(parents=True, exist_ok=True)
    (apps_dir / f"{name}.puppy").write_text(
        "[ENTRY]\n"
        "CATEGORY=Ports\n"
        f"NAME={title}\n"
        f"DESCRIPTION={title}\n"
        f"ICON=/home/player/.local/share/icons/{name}.png\n"
        f"COMMAND=/home/player/ports/{name}/run.sh\n",
        encoding="utf-8",
    )
    make_icon(name, title, icons_dir / f"{name}.png")

    print(f"created apps/{name}, ports/{name} and the launcher entry for '{title}'")
    print(f"next: edit apps/{name}/main.lua, then python3 build.py and tests/run_headless.sh {name}")


if __name__ == "__main__":
    main()
