# goodluckOS app template

Start with TUTORIAL.md. It takes about 40 minutes the first time.

Quick start:

    python3 new_app.py my-app "My App"
    python3 build.py
    tests/run_headless.sh my-app
