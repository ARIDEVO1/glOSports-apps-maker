#!/usr/bin/env python3
"""Build every app into ports/<name>/<name>.love.

A .love file is a zip with main.lua at its root. Each app's own *.lua files
and the shared/*.lua modules go into the zip.
"""
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent

for app_dir in sorted((ROOT / "apps").iterdir()):
    if not app_dir.is_dir():
        continue
    name = app_dir.name
    out = ROOT / "ports" / name / f"{name}.love"
    out.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(app_dir.glob("*.lua")) + sorted((ROOT / "shared").glob("*.lua"))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, f.name)
    print(f"wrote {out} ({out.stat().st_size} bytes, {len(files)} files)")
